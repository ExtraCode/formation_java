package castellet;

import java.util.ArrayList;

public class Ecurie extends Protagoniste {
	
	private static ArrayList<Ecurie> ecuries = new ArrayList<>();
	private ArrayList<Voiture> voitures = new ArrayList<>();
	private ArrayList<Pilote> pilotes = new ArrayList<>();

	public Ecurie(String nom, String nationalite) {

		super(nom, nationalite);
		ecuries.add(this);

	}

	public static ArrayList<Ecurie> getEcuries() {
		return ecuries;
	}

	public static void setEcuries(ArrayList<Ecurie> ecuries) {
		Ecurie.ecuries = ecuries;
	}

	public ArrayList<Voiture> getVoitures() {
		return voitures;
	}

	public void setVoitures(ArrayList<Voiture> voitures) {
		this.voitures = voitures;
	}

	public ArrayList<Pilote> getPilotes() {
		return pilotes;
	}

	public void setPilotes(ArrayList<Pilote> pilotes) {
		this.pilotes = pilotes;
	}

}
